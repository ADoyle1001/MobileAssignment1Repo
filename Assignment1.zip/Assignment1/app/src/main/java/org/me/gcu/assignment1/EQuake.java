// Anthony Doyle S1427055
package org.me.gcu.assignment1;

import java.util.Date;

public class EQuake {



    private String title;
    private String description;



    private String link;
    private String date;
    private String category;
    private String latitude;
    private String longitude;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public EQuake()
    {
        title = "";
        description = "";
        link = "";
        date = "" ;
        category = "";
        latitude = "" ;
        longitude = "";
    }

    public EQuake(String atitle, String adescription,String alink,String adate,String acategory, String alatitude, String alongtitude)
    {
        title = atitle;
        description = adescription;
        link = alink;
        date = adate;
        category = acategory;
        latitude = alatitude;
        longitude = alongtitude;
    }



    public String toString()
    {
        String temp;

        temp = title + " " + " " + description + " " + link + " " +  date + " " + category + " " + latitude + " " + longitude;

        return temp;
    }

} // End of class
