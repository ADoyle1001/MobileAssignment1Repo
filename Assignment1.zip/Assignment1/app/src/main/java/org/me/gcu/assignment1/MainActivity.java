//Anthony Doyle S1427055
package org.me.gcu.assignment1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.res.Configuration;
import android.os.AsyncTask;
import android.os.Bundle;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Array;
import java.net.URL;
import java.net.URLConnection;

import android.util.Log;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;
import java.io.IOException;
import java.io.StringReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import android.widget.AdapterView;
import android.widget.Toast;

import org.me.gcu.assignment1.R;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemClickListener, View.OnClickListener
{
    private TextView rawDataDisplay;
    private Button startButton;
    private String result = "";
    private String url1="";
    private String urlSource="http://quakes.bgs.ac.uk/feeds/MhSeismology.xml";
    private ListView listView;
    private LinkedList <EQuake> alist = new LinkedList<>();
    private ArrayAdapter adapter;
    private ArrayList<String> items;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {

        items = new ArrayList<String>();


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.e("MyTag","in onCreate");
        // Set up the raw links to the graphical components
        //rawDataDisplay = (TextView)findViewById(R.id.rawDataDisplay);
        startButton = (Button)findViewById(R.id.startButton);
        startButton.setOnClickListener(this);
        Log.e("MyTag","after startButton");






        listView = (ListView) findViewById(R.id.List);
        listView.setOnItemClickListener(this);

        adapter = new ArrayAdapter<String>(this,
                R.layout.list_style,R.id.label,items);

        if (adapter == null)
        {
            Log.e("MyTag","Adapter error");
        }

        // Assign adapter to ListView
        listView.setAdapter(adapter);





    } // End of onCreate





    public void onClick(View aview)
    {
        Log.e("MyTag","in onClick");
        startProgress();
        Log.e("MyTag","after startProgress");


    }

    public void startProgress()
    {
        // Run network access on a separate thread;
        new Thread(new Task(urlSource)).start();

    } //

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id)
    {


    }

    // Need separate thread to access the internet resource over network
    // Other neater solutions should be adopted in later iterations.
    private class Task implements Runnable
    {
        private String url;

        public Task(String aurl)
        {
            url = aurl;
        }
        @Override
        public void run()
        {

            URL aurl;
            URLConnection yc;
            BufferedReader in = null;
            String inputLine = "";


            Log.e("MyTag","in run");

            try
            {
                Log.e("MyTag","in try");
                aurl = new URL(url);
                yc = aurl.openConnection();
                in = new BufferedReader(new InputStreamReader(yc.getInputStream()));
                Log.e("MyTag","after ready");
                //
                // Now read the data. Make sure that there are no specific hedrs
                // in the data file that you need to ignore.
                // The useful data that you need is in each of the item entries
                //
                while ((inputLine = in.readLine()) != null)
                {
                    result = result + inputLine;
                    Log.e("MyTag",inputLine);

                }
                in.close();
            }
            catch (IOException ae)
            {
                Log.e("MyTag", "ioexception in run");
            }

            alist = parseData(result);

            // Write list to Log for testing
            if (alist != null)
            {
                Log.e("MyTag","List not null");
                int count = 0;
                for (Object o : alist)
                {
                    Log.e("MyTag",o.toString());
                    items.add(o.toString());
                    count = count + 1;
                }
                Log.e("My Tag", "Array is " + items.toString());
            }
            else
            {
                Log.e("MyTag","List is null");
            }


            MainActivity.this.runOnUiThread(new Runnable()
            {
                public void run() {
                    Log.d("UI thread", "I am the UI thread");
                    //rawDataDisplay.setText(result);

                    listView.setAdapter(adapter);


                }
            });


        }

    }




    private LinkedList<EQuake> parseData(String dataToParse)
    {
        Boolean hasStarted = false;
        EQuake quake = null;

        try
        {
            XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
            factory.setNamespaceAware(true);
            XmlPullParser xpp = factory.newPullParser();
            xpp.setInput( new StringReader( dataToParse ) );
            int eventType = xpp.getEventType();
            while (eventType != XmlPullParser.END_DOCUMENT)
            {
                // Found a start tag
                if(eventType == XmlPullParser.START_TAG & hasStarted == true)
                {

                    if (xpp.getName().equalsIgnoreCase("item"))
                    {
                        Log.e("MyTag","Item Start Tag found");
                        if (alist.isEmpty()) {
                            alist = new LinkedList<EQuake>();
                        }
                        quake = new EQuake();

                    }
                    else
                    if (xpp.getName().equalsIgnoreCase("title"))
                    {
                        // Now just get the associated text
                        String temp = xpp.nextText();
                        // Do something with text
                        Log.e("MyTag","Title is " + temp);
                        quake.setTitle(temp);
                    }
                    else
                        // Check which Tag we have
                        if (xpp.getName().equalsIgnoreCase("description"))
                        {
                            // Now just get the associated text
                            String temp = xpp.nextText();
                            // Do something with text
                            Log.e("MyTag","Description is " + temp);
                            quake.setDescription(temp);
                        }
                        else
                            // Check which Tag we have
                            if (xpp.getName().equalsIgnoreCase("link"))
                            {
                                // Now just get the associated text
                                String temp = xpp.nextText();
                                // Do something with text
                                Log.e("MyTag","Link is " + temp);
                                quake.setLink(temp);
                            }
                            else
                                if (xpp.getName().equalsIgnoreCase("pubDate"))
                                {
                                    // Now just get the associated text
                                    String temp = xpp.nextText();
                                    // Do something with text
                                    Log.e("MyTag","Date is " + temp);
                                    quake.setDate(temp);
                                }
                                else
                                if (xpp.getName().equalsIgnoreCase("category"))
                                {
                                    // Now just get the associated text
                                    String temp = xpp.nextText();
                                    // Do something with text
                                    Log.e("MyTag","Category is " + temp);
                                    quake.setCategory(temp);
                                }
                                else
                                    if (xpp.getName().equalsIgnoreCase("latitude"))
                                    {
                                        // Now just get the associated text
                                        String temp = xpp.nextText();
                                        // Do something with text
                                        Log.e("MyTag","Latitude is " + temp);
                                        quake.setLatitude(temp);

                                    }
                                    else
                                    if (xpp.getName().equalsIgnoreCase("longitude"))
                                    {
                                        // Now just get the associated text
                                        String temp = xpp.nextText();
                                        // Do something with text
                                        Log.e("MyTag","Longitude is " + temp);
                                        quake.setLongitude(temp);

                                    }
                }
                else
                if(eventType == XmlPullParser.END_TAG)
                {
                    if (xpp.getName().equalsIgnoreCase("image"))
                    {
                        hasStarted = true;
                    }
                    else
                    if (xpp.getName().equalsIgnoreCase("item"))
                    {
                        Log.e("MyTag","item is " + quake.toString());
                        alist.add(quake);


                    }
                    else
                    if (xpp.getName().equalsIgnoreCase("channel"))
                    {
                        int size;
                        size = alist.size();
                        // Write list to Log for testing
                        if (alist != null)
                        {
                            Log.e("MyTag","List not null");
                            int count = 0;
                            for (Object o : alist)
                            {
                                Log.e("MyTag",o.toString());
                                items.add(o.toString());
                                count = count + 1;
                            }
                            Log.e("My Tag", "Array is " + items.toString());
                        }
                        else
                        {
                            Log.e("MyTag","List is null");
                        }

                        Log.e("MyTag","Quake list size is " + size + " and adaptersize is " + adapter.getCount());
                    }
                }


                // Get the next event
                eventType = xpp.next();

            } // End of while

            //return alist;
        }
        catch (XmlPullParserException ae1)
        {
            Log.e("MyTag","Parsing error" + ae1.toString());
        }
        catch (IOException ae1)
        {
            Log.e("MyTag","IO error during parsing");
        }

        Log.e("MyTag","End document");


        return alist;


    }

}